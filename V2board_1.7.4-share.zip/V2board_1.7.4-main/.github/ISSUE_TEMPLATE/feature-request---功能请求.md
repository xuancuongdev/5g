---
name: Feature request | 功能请求
about: Tell us what you need
title: "[Feature request]"
labels: ''
assignees: ''

---

Please describe in detail the problems or needs you have encountered.
请详细描述你遇到的问题或需求。
